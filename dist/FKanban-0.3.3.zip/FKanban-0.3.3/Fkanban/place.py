# -*-coding:Latin-1 -*
from ui_object import *

class place(ui_object):
	''' a place to produice
	'''
	def __init__(self, name = "unamed"):
		'''Initialisation
			- name
		'''
		self.name = name