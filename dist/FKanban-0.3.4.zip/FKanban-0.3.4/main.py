# -*-coding:Latin-1 -*

from Fkanban.Fkanban import *
from Fkanban.ui_Fkanban import *
from FUTIL.my_logging import *

my_logging(console_level = INFO, logfile_level = INFO, details = False)

from config import *
