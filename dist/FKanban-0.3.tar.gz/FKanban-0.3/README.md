Fkanban Lib - A kanban simulation for manufacturing
========================================================================

Utilisation

	- see examples
	
	
Installation :
	sudo python setup.py install


	